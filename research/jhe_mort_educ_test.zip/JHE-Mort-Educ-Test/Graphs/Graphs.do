* JHE GRAPHS

* This file produces data for four graphs in the paper.

clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\combine\output"

use master.dta

* STEP GRAPHS

table educ_grp6 sex if nlms1980s [aw = agestdwgt], c(mean mort_ind semean mort_ind)
table educ_grp6 sex if nlms1980s [pw = agestdwgt], row format(%10.0f)

table educ_grp6 sex if nhis1990s [aw = agestdwgt], c(mean mort_ind semean mort_ind)
table educ_grp6 sex if nhis1990s [pw = agestdwgt], row format(%10.0f)

table educ_grp6 sex if nhis2000s [aw = agestdwgt], c(mean mort_ind semean mort_ind)
table educ_grp6 sex if nhis2000s [pw = agestdwgt], row format(%10.0f)

* DEMEANED MORTALITY RATES

table educ_grp6 sex if nlms1980s [aw = agestdwgt], c(mean mort_ind_demean semean mort_ind_demean)
table educ_grp6 sex if nlms1990s [aw = agestdwgt], c(mean mort_ind_demean semean mort_ind_demean)
table educ_grp6 sex if nhis2000s [aw = agestdwgt], c(mean mort_ind_demean semean mort_ind_demean)
