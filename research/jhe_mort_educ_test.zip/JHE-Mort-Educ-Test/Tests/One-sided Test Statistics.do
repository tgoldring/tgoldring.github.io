clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test"

use Data/combine/output/master.dta
set linesize 240

* CREATE PARTITION SHARES FOR FEMALES

forvalues i = 1(1)6 {
	reg nlms1980s_ptn`i' if nlms1980s == 1 & sex == 2 [aw = agestdwgt]
	scalar nlms1980s_ptn`i'_f_share = _b[_cons]
}

reg nlms1980s_lower2 if nlms1980s == 1 & sex == 2 [aw = agestdwgt]
scalar nlms1980s_lower2_f_share = _b[_cons]

forvalues i = 1(1)6 {
	reg nhis1990s_ptn`i' if nhis1990s == 1 & sex == 2 [aw = agestdwgt]
	scalar nhis1990s_ptn`i'_f_share = _b[_cons]
}

reg nhis1990s_lower2 if nhis1990s == 1 & sex == 2 [aw = agestdwgt]
scalar nhis1990s_lower2_f_share = _b[_cons]

forvalues i = 1(1)6 {
	reg nhis2000s_ptn`i' if nhis2000s == 1 & sex == 2 [aw = agestdwgt]
	scalar nhis2000s_ptn`i'_f_share = _b[_cons]
}

reg nhis2000s_lower2 if nhis2000s == 1 & sex == 2 [aw = agestdwgt]
scalar nhis2000s_lower2_f_share = _b[_cons]

* DEFINE PARTITION CONSTRAINTS FOR FEMALES

constraint define 1 (nlms1980s_ptn1 * nlms1980s_ptn1_f_share) + ///
	(nlms1980s_ptn2 * nlms1980s_ptn2_f_share) + ///
	(nlms1980s_ptn3 * nlms1980s_ptn3_f_share) + ///
	(nlms1980s_ptn4 * nlms1980s_ptn4_f_share) + ///
	(nlms1980s_ptn5 * nlms1980s_ptn5_f_share) + ///
	(nlms1980s_ptn6 * nlms1980s_ptn6_f_share) = 0

constraint define 2 (nlms1980s_lower2 * nlms1980s_lower2_f_share) + ///
	(nlms1980s_ptn3 * nlms1980s_ptn3_f_share) + ///
	(nlms1980s_ptn4 * nlms1980s_ptn4_f_share) + ///
	(nlms1980s_ptn5 * nlms1980s_ptn5_f_share) + ///
	(nlms1980s_ptn6 * nlms1980s_ptn6_f_share) = 0

constraint define 3 (nhis1990s_ptn1 * nhis1990s_ptn1_f_share) + ///
	(nhis1990s_ptn2 * nhis1990s_ptn2_f_share) + ///
	(nhis1990s_ptn3 * nhis1990s_ptn3_f_share) + ///
	(nhis1990s_ptn4 * nhis1990s_ptn4_f_share) + ///
	(nhis1990s_ptn5 * nhis1990s_ptn5_f_share) + ///
	(nhis1990s_ptn6 * nhis1990s_ptn6_f_share) = 0

constraint define 4 (nhis1990s_lower2 * nhis1990s_lower2_f_share) + ///
	(nhis1990s_ptn3 * nhis1990s_ptn3_f_share) + ///
	(nhis1990s_ptn4 * nhis1990s_ptn4_f_share) + ///
	(nhis1990s_ptn5 * nhis1990s_ptn5_f_share) + ///
	(nhis1990s_ptn6 * nhis1990s_ptn6_f_share) = 0

constraint define 5 (nhis2000s_ptn1 * nhis2000s_ptn1_f_share) + ///
	(nhis2000s_ptn2 * nhis2000s_ptn2_f_share) + ///
	(nhis2000s_ptn3 * nhis2000s_ptn3_f_share) + ///
	(nhis2000s_ptn4 * nhis2000s_ptn4_f_share) + ///
	(nhis2000s_ptn5 * nhis2000s_ptn5_f_share) + ///
	(nhis2000s_ptn6 * nhis2000s_ptn6_f_share) = 0

constraint define 6 (nhis2000s_lower2 * nhis2000s_lower2_f_share) + ///
	(nhis2000s_ptn3 * nhis2000s_ptn3_f_share) + ///
	(nhis2000s_ptn4 * nhis2000s_ptn4_f_share) + ///
	(nhis2000s_ptn5 * nhis2000s_ptn5_f_share) + ///
	(nhis2000s_ptn6 * nhis2000s_ptn6_f_share) = 0

* CREATE PARTITION SHARES FOR MALES

forvalues i = 1(1)6 {
	reg nlms1980s_ptn`i' if nlms1980s == 1 & sex == 1 [aw = agestdwgt]
	scalar nlms1980s_ptn`i'_m_share = _b[_cons]
}

reg nlms1980s_lower2 if nlms1980s == 1 & sex == 1 [aw = agestdwgt]
scalar nlms1980s_lower2_m_share = _b[_cons]

forvalues i = 1(1)6 {
	reg nhis1990s_ptn`i' if nhis1990s == 1 & sex == 1 [aw = agestdwgt]
	scalar nhis1990s_ptn`i'_m_share = _b[_cons]
}

reg nhis1990s_lower2 if nhis1990s == 1 & sex == 1 [aw = agestdwgt]
scalar nhis1990s_lower2_m_share = _b[_cons]

forvalues i = 1(1)6 {
	reg nhis2000s_ptn`i' if nhis2000s == 1 & sex == 1 [aw = agestdwgt]
	scalar nhis2000s_ptn`i'_m_share = _b[_cons]
}

reg nhis2000s_lower2 if nhis2000s == 1 & sex == 1 [aw = agestdwgt]
scalar nhis2000s_lower2_m_share = _b[_cons]

* DEFINE PARTITION CONSTRAINTS FOR MALES

constraint define 7 (nlms1980s_ptn1 * nlms1980s_ptn1_m_share) + ///
	(nlms1980s_ptn2 * nlms1980s_ptn2_m_share) + ///
	(nlms1980s_ptn3 * nlms1980s_ptn3_m_share) + ///
	(nlms1980s_ptn4 * nlms1980s_ptn4_m_share) + ///
	(nlms1980s_ptn5 * nlms1980s_ptn5_m_share) + ///
	(nlms1980s_ptn6 * nlms1980s_ptn6_m_share) = 0

constraint define 8 (nlms1980s_lower2 * nlms1980s_lower2_m_share) + ///
	(nlms1980s_ptn3 * nlms1980s_ptn3_m_share) + ///
	(nlms1980s_ptn4 * nlms1980s_ptn4_m_share) + ///
	(nlms1980s_ptn5 * nlms1980s_ptn5_m_share) + ///
	(nlms1980s_ptn6 * nlms1980s_ptn6_m_share) = 0

constraint define 9 (nhis1990s_ptn1 * nhis1990s_ptn1_m_share) + ///
	(nhis1990s_ptn2 * nhis1990s_ptn2_m_share) + ///
	(nhis1990s_ptn3 * nhis1990s_ptn3_m_share) + ///
	(nhis1990s_ptn4 * nhis1990s_ptn4_m_share) + ///
	(nhis1990s_ptn5 * nhis1990s_ptn5_m_share) + ///
	(nhis1990s_ptn6 * nhis1990s_ptn6_m_share) = 0

constraint define 10 (nhis1990s_lower2 * nhis1990s_lower2_m_share) + ///
	(nhis1990s_ptn3 * nhis1990s_ptn3_m_share) + ///
	(nhis1990s_ptn4 * nhis1990s_ptn4_m_share) + ///
	(nhis1990s_ptn5 * nhis1990s_ptn5_m_share) + ///
	(nhis1990s_ptn6 * nhis1990s_ptn6_m_share) = 0

constraint define 11 (nhis2000s_ptn1 * nhis2000s_ptn1_m_share) + ///
	(nhis2000s_ptn2 * nhis2000s_ptn2_m_share) + ///
	(nhis2000s_ptn3 * nhis2000s_ptn3_m_share) + ///
	(nhis2000s_ptn4 * nhis2000s_ptn4_m_share) + ///
	(nhis2000s_ptn5 * nhis2000s_ptn5_m_share) + ///
	(nhis2000s_ptn6 * nhis2000s_ptn6_m_share) = 0

constraint define 12 (nhis2000s_lower2 * nhis2000s_lower2_m_share) + ///
	(nhis2000s_ptn3 * nhis2000s_ptn3_m_share) + ///
	(nhis2000s_ptn4 * nhis2000s_ptn4_m_share) + ///
	(nhis2000s_ptn5 * nhis2000s_ptn5_m_share) + ///
	(nhis2000s_ptn6 * nhis2000s_ptn6_m_share) = 0

* GRADIENT TESTS

* A. 1980s - 2000s
log using Tests\Log Files\gradient_test_1980s-2000s.log, replace

* FEMALES

cnsreg mort_ind nlms1980s_ptn* nhis2000s_ptn* nhis2000s [aw = agestdwgt] if ///
	sex == 2 & (mort_window == 1983 | mort_window == 2002), c(1, 5) ///
	collinear vce(cluster record)
test (_b[nhis2000s_ptn5] - _b[nlms1980s_ptn5] = 0) ///
	(_b[nhis2000s_ptn6] - _b[nlms1980s_ptn6] = 0)
di r(F) * 2

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("F 1980s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES

cnsreg mort_ind nlms1980s_ptn* nhis2000s_ptn* nhis2000s [aw = agestdwgt] if ///
	sex == 1 & (mort_window == 1983 | mort_window == 2002), c(7, 11) ///
	collinear vce(cluster record)
* None of the partitions shift weakly lower in the distribution of educational
* attainment and also have lower average mortality over time.

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("M 1980s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

cap log close

* B. 1980s - 1990s
log using Tests\Log Files\gradient_test_1980s-1990s.log, replace

* FEMALES

cnsreg mort_ind nlms1980s_ptn* nhis1990s_ptn* nhis1990s [aw = agestdwgt] if ///
	sex == 2 & (mort_window == 1983 | mort_window == 1992), c(1, 3) ///
	collinear vce(cluster record)
test (_b[nhis1990s_ptn3] - _b[nlms1980s_ptn3] = 0)
di r(F)

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("F 1980s-1990s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES

cnsreg mort_ind nlms1980s_ptn* nhis1990s_ptn* nhis1990s [aw = agestdwgt] if ///
	sex == 1 & (mort_window == 1983 | mort_window == 1992), c(7, 9) ///
	collinear vce(cluster record)
* None of the partitions shift weakly lower in the distribution of educational
* attainment and also have lower average mortality over time.

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("M 1980s-1990s") modify keepcellformat
* matrix list e(V), format(%11.10f)

cap log close

* C. 1990s - 2000s
log using Tests\Log Files\gradient_test_1990s-2000s.log, replace

* FEMALES

cnsreg mort_ind nhis1990s_ptn* nhis2000s_ptn* nhis2000s [aw = agestdwgt] if ///
	sex == 2 & (mort_window == 1992 | mort_window == 2002), c(3, 5) ///
	collinear vce(cluster record)
test (_b[nhis2000s_ptn5] - _b[nhis1990s_ptn5] = 0) ///
	(_b[nhis2000s_ptn6] - _b[nhis1990s_ptn6] = 0)
di r(F) * 2

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("F 1990s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES
cnsreg mort_ind nhis1990s_ptn* nhis2000s_ptn* nhis2000s [aw = agestdwgt] if ///
	sex == 1 & (mort_window == 1992 | mort_window == 2002), c(9, 11) ///
	collinear vce(cluster record)
test (_b[nhis2000s_ptn6] - _b[nhis1990s_ptn6] = 0)
di r(F)

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Rotation matrices.xlsx", ///
	sheet("M 1990s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

cap log close

* ROTATION TESTS

* A. 1980s - 2000s
log using Tests\Log Files\rotation_test_1980s-2000s.log, replace

* FEMALES

cnsreg mort_ind nlms1980s_ptn* nhis2000s_lower2 ///
	nhis2000s_ptn3-nhis2000s_ptn6 nhis2000s [aw = agestdwgt] if sex == 2 & ///
	(mort_window == 1983 | mort_window == 2002), c(1, 6) collinear ///
	vce(cluster record)
test (_b[nlms1980s_ptn1] - _b[nhis2000s_lower2] = 0) ///
	(_b[nhis2000s_ptn6] - _b[nlms1980s_ptn6] = 0)
di r(F) * 2

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("F 1980s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES

cnsreg mort_ind nlms1980s_ptn* nhis2000s_lower2 ///
	nhis2000s_ptn3-nhis2000s_ptn6 nhis2000s [aw = agestdwgt] if sex == 1 & ///
	(mort_window == 1983 | mort_window == 2002), c(7, 12) collinear ///
	vce(cluster record)
test (_b[nlms1980s_ptn1] - _b[nhis2000s_lower2] = 0)
di r(F)

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("M 1980s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

cap log close

* B. 1980s - 1990s
log using Tests\Log Files\rotation_test_1980s-1990s.log, replace

* FEMALES
cnsreg mort_ind nlms1980s_ptn* nhis1990s_lower2 ///
	nhis1990s_ptn3-nhis1990s_ptn6 nhis1990s [aw = agestdwgt] if sex == 2 & ///
	(mort_window == 1983 | mort_window == 1992), c(1, 4) collinear ///
	vce(cluster record)
test (_b[nlms1980s_ptn1] - _b[nhis1990s_lower2] = 0)
di r(F)

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("F 1980s-1990s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES

cnsreg mort_ind nlms1980s_ptn* nhis1990s_lower2 ///
	nhis1990s_ptn3-nhis1990s_ptn6 nhis1990s [aw = agestdwgt] if sex == 1 & ///
	(mort_window == 1983 | mort_window == 1992), c(7, 10) collinear ///
	vce(cluster record)
* The highest and lowest partitions both do not violate the null hypothesis.

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("M 1980s-1990s") modify keepcellformat
* matrix list e(V), format(%11.10f)

log close

* C. 1990s - 2000s
log using Tests\Log Files\rotation_test_1990s-2000s.log, replace

* FEMALES

cnsreg mort_ind nhis1990s_ptn* nhis2000s_lower2 ///
	nhis2000s_ptn3-nhis2000s_ptn6 nhis2000s [aw = agestdwgt] if sex == 2 & ///
	(mort_window == 1992 | mort_window == 2002), c(3, 6) collinear ///
	vce(cluster record)
test (_b[nhis1990s_ptn1] - _b[nhis2000s_lower2] = 0) ///
	(_b[nhis2000s_ptn6] - _b[nhis1990s_ptn6] = 0)
di r(F) * 2

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("F 1990s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

* MALES

cnsreg mort_ind nhis1990s_ptn* nhis2000s_lower2 ///
	nhis2000s_ptn3-nhis2000s_ptn6 nhis2000s [aw = agestdwgt] if sex == 1 & ///
	(mort_window == 1992 | mort_window == 2002), c(9, 12) collinear ///
	vce(cluster record)
test (_b[nhis2000s_ptn6] - _b[nhis1990s_ptn6] = 0)
di r(F)

putexcel A1=matrix(e(V), names) using "Tests\Var-Covar Matrices\Gradient matrices.xlsx", ///
	sheet("M 1990s-2000s") modify keepcellformat
* matrix list e(V), format(%11.10f)

log close
