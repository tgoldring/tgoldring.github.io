README FOR ONE-SIDED TESTS

1. "One-sided Test Statistics.do" creates one-sided test statistics for both tests described in the paper. The output is printed to log files which are located in the 'Log Files' subfolder.

2. "One-sided Test Statistics.do" also adds var-covar matrices to Excel files in the 'Var-Covar Matrices' subfolder.

3. "Simulate Weights.R" and "One-sided Test Critical Value Calculation.xlsx" calculate critical values for the one-sided tests.

4. All files in this folder combine to produce the test results in the paper in Table 3.