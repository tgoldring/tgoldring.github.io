### SHIFT TEST

# A) Import Data

setwd("C:/Users/sethrs/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")
# setwd("C:/Users/Seth/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")

input.f <- read.csv("vcov_female_<x-y>.csv", header=T)
input.m <- read.csv("vcov_male_<x-y>.csv", header=T)

input.f[is.na(input.f)] <- 0
input.m[is.na(input.m)] <- 0

# Actual VCov matrix:

vcovB.f <- as.matrix(input.f[1:12,2:13])
  rownames(vcovB.f) <- input.f$X

vcovB.m <- as.matrix(input.m[1:12,2:13])
  rownames(vcovB.m) <- input.m$X

# Make symmetric:
# 
# vcovB.f <- vcovB.f + t(vcovB.f)
#   diag(vcovB.f) <- diag( as.matrix(input.f[1:12,2:13]) )
# 
# vcovB.m <- vcovB.m + t(vcovB.m)
#   diag(vcovB.m) <- diag( as.matrix(input.m[1:12,2:13]) )

# B) VCov of Differences

# Difference matrix:

A <- rbind(
  c(-1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0),
  c( 0,-1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0),
  c( 0, 0,-1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
  c( 0, 0, 0,-1, 0, 0, 0, 0, 0, 1, 0, 0),
  c( 0, 0, 0, 0,-1, 0, 0, 0, 0, 0, 1, 0),
  c( 0, 0, 0, 0, 0,-1, 0, 0, 0, 0, 0, 1) )

vcovD.f <- A %*% vcovB.f %*% t(A)
vcovD.m <- A %*% vcovB.m %*% t(A)

# C) Simulate

# Cholesky decomposition:

cholD.f <- chol(vcovD.f)
cholD.m <- chol(vcovD.m)

# Draw shocks:

sims <- 100000

Draws <- matrix(
  rnorm(sims*nrow(A)),
  nrow=sims, ncol=nrow(A)
  )

# Check simulation accuracy:

simvarD.f <- cov(Draws %*% cholD.f)
simvarD.m <- cov(Draws %*% cholD.m)

round(vcovD.f*1000^2,3); round(simvarD.f*1000^2,3)
  round( (simvarD.f - vcovD.f)*1000^2, 3)

round(vcovD.m*1000^2,3); round(simvarD.m*1000^2,3)
  round( (simvarD.m - vcovD.m)*1000^2, 3)

# Count number of negative elements:
# (with correlation via decomposed vcov matrix)

numneg.f <- rowSums(Draws %*% t(cholD.f) < 0) 
numneg.m <- rowSums(Draws %*% t(cholD.m) < 0) 

# D) Results

cbind( table(numneg.f) / length(numneg.f) )
cbind( table(numneg.m) / length(numneg.m) )



### ROTATION TEST

# A) Import Data

setwd("C:/Users/sethrs/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")
# setwd("C:/Users/Seth/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")

input.f <- read.csv("vcov_frot_<x-y>.csv", header=T)
input.m <- read.csv("vcov_mrot_<x-y>.csv", header=T)

input.f[is.na(input.f)] <- 0
input.m[is.na(input.m)] <- 0

# Actual VCov matrix:

vcovB.f <- as.matrix(input.f[1:11,2:12])
  rownames(vcovB.f) <- input.f$X

vcovB.m <- as.matrix(input.m[1:11,2:12])
  rownames(vcovB.m) <- input.m$X

# Make symmetric:
# 
# vcovB.f <- vcovB.f + t(vcovB.f)
#   diag(vcovB.f) <- diag( as.matrix(input.f[1:11,2:12]) )
# 
# vcovB.m <- vcovB.m + t(vcovB.m)
#   diag(vcovB.m) <- diag( as.matrix(input.m[1:11,2:12]) )

# B) VCov of Differences

# Difference matrix:

A <- rbind(
  c( 1, 0, 0, 0, 0, 0,-1, 0, 0, 0, 0),
  c( 0, 0, 0, 0, 0,-1, 0, 0, 0, 0, 1) )

vcovD.f <- A %*% vcovB.f %*% t(A)
vcovD.m <- A %*% vcovB.m %*% t(A)

# C) Simulate

# Cholesky decomposition:

cholD.f <- chol(vcovD.f)
cholD.m <- chol(vcovD.m)

# Draw shocks:

sims <- 100000

Draws <- matrix(
  rnorm(sims*nrow(A)),
  nrow=sims, ncol=nrow(A)
  )

# Check simulation accuracy:

simvarD.f <- cov(Draws %*% cholD.f)
simvarD.m <- cov(Draws %*% cholD.m)

round(vcovD.f*1000^2,3); round(simvarD.f*1000^2,3)
  round( (simvarD.f - vcovD.f)*1000^2, 3)

round(vcovD.m*1000^2,3); round(simvarD.m*1000^2,3)
  round( (simvarD.m - vcovD.m)*1000^2, 3)

# Count number of negative elements:
# (with correlation via decomposed vcov matrix)

numneg.f <- rowSums(Draws %*% t(cholD.f) < 0) 
numneg.m <- rowSums(Draws %*% t(cholD.m) < 0) 

# D) Results

cbind( table(numneg.f) / length(numneg.f) )
cbind( table(numneg.m) / length(numneg.m) )



### SHIFT TEST, MAX 4 PARTS SHIFT
#   (Use for males 1983-1992)

# A) Import Data

setwd("C:/Users/sethrs/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")
# setwd("C:/Users/Seth/Dropbox/Education-Mortality Research Project/Analyses/Gradient Tests/Var-Covar Matrices")

input.m <- read.csv("vcov_male_1983-1992.csv", header=T)

input.m[is.na(input.m)] <- 0

# Actual VCov matrix:

vcovB.m <- as.matrix(input.m[1:12,2:13])
  rownames(vcovB.m) <- input.m$X

# Make symmetric:
# 
# vcovB.m <- vcovB.m + t(vcovB.m)
#   diag(vcovB.m) <- diag( as.matrix(input.m[1:12,2:13]) )

# B) VCov of Differences

# Difference matrix:

A <- rbind(
  c(-1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0),
  c( 0,-1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0),
  c( 0, 0,-1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
  c( 0, 0, 0, 0, 0,-1, 0, 0, 0, 0, 0, 1) )

vcovD.m <- A %*% vcovB.m %*% t(A)

# C) Simulate

# Cholesky decomposition:

cholD.m <- chol(vcovD.m)

# Draw shocks:

sims <- 100000

Draws <- matrix(
  rnorm(sims*nrow(A)),
  nrow=sims, ncol=nrow(A)
  )

# Check simulation accuracy:

simvarD.m <- cov(Draws %*% cholD.m)

round(vcovD.m*1000^2,3); round(simvarD.m*1000^2,3)
  round( (simvarD.m - vcovD.m)*1000^2, 3)

# Count number of negative elements:
# (with correlation via decomposed vcov matrix)

numneg.m <- rowSums(Draws %*% t(cholD.m) < 0) 

# D) Results

cbind( table(numneg.m) / length(numneg.m) )



### CHECK

# Compare with MVN simulator:

library(mvtnorm)

temp <- rmvnorm(100000, sigma=vcovD.f)

round(vcovD.f*1000^2,3); round( cov(temp)*1000^2, 3)
  round( (cov(temp) - vcovD.f)*1000^2, 3)

