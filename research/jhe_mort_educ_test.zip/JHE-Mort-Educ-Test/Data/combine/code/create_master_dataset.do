clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/Combine"

* Load data for all three decades
use ../NLMS/output/nlms1980s.dta
qui append using ../NHIS/output/nhis1990s.dta, keep(record mort_window svy_yr ///
	sex race hisp age age_grp region educ educ_grp6 educ_grp3 edrank_current ///
	educ_dum* mort_ind agestdwgt wt)
qui append using ../NHIS/output/nhis2000s.dta, keep(record mort_window svy_yr ///
	sex race hisp age age_grp region educ educ_grp6 educ_grp3 edrank_current ///
	educ_dum* mort_ind agestdwgt wt)

* Create sample dummies
gen nlms1980s = (mort_window == 1983)
gen nhis1990s = (mort_window == 1992)
gen nhis2000s = (mort_window == 2002)

* Create education-sample dummies
forvalues i = 1(1)6 {
	gen nlms1980s_ptn`i' = educ_dum`i' * nlms1980s
	gen nhis1990s_ptn`i' = educ_dum`i' * nhis1990s
	gen nhis2000s_ptn`i' = educ_dum`i' * nhis2000s
}

* Create dummy for bottom two education groups
gen nlms1980s_lower2 = 0
gen nhis1990s_lower2 = 0
gen nhis2000s_lower2 = 0

replace nlms1980s_lower2 = 1 if nlms1980s == 1 & (educ_grp6 == 1 | educ_grp6 == 2)
replace nhis1990s_lower2 = 1 if nhis1990s == 1 & (educ_grp6 == 1 | educ_grp6 == 2)
replace nhis2000s_lower2 = 1 if nhis2000s == 1 & (educ_grp6 == 1 | educ_grp6 == 2)

* Create demeaned mortality indicator
foreach i in nlms1980s nhis1990s nhis2000s {
	preserve
	collapse (mean) mort_window mort_ind [aw = agestdwgt] if `i' == 1, by(sex)
	rename mort_ind avg_mort
	sort mort_window sex
	qui save avg_mort_`i'_temp.dta, replace
	restore
	sort mort_window sex
	qui merge m:1 mort_window sex using avg_mort_`i'_temp.dta, nogen update
	erase avg_mort_`i'_temp.dta
}

gen mort_ind_demean = mort_ind - avg_mort

* Drop unneeded variables
drop hhid stater educ_orig

* Order and save master dataset
compress
order mort_window nlms1980s nhis1990s nhis2000s record svy_yr sex race hisp ///
	age age_grp region educ educ_grp6 educ_grp3 educ educ_dum* ///
	edrank_current mort_ind mort_ind_demean follow agestdwgt wt ///
	nlms1980s_ptn* nlms1980s_lower2 nhis1990s_ptn* nhis1990s_lower2 ///
	nhis2000s_ptn* nhis2000s_lower2 avg_mort

sort mort_window record
save output/master.dta, replace
