README FOR CREATING MASTER DATASET

1. "create_master_dataset.do" combines the three decadal datasets into the master dataset used for all tables and figures in the paper.

2. The final master dataset used in the paper is located in the 'output' folder.

3. Additional detail on specific commands may be found within the do file.
