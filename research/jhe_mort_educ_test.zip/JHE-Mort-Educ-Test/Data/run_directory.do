**** run_directory.do ****
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data"

do NHIS/code/run_directory.do
do NLMS/code/run_directory.do
do Combine/code/create_master_dataset.do
