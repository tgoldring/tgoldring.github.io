clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\NLMS"

* Import NLMS data file
infix using input/dictionary_11.dct

* Clean and recode variables
replace educ = "." if educ == ".."
rename educ educ_orig
destring hisp, replace
destring educ, replace

* Create region
gen region = .
replace region = 1 if stater == 11 | stater == 12 | stater == 13 | ///
	stater == 14 | stater == 15 | stater == 16
replace region = 1 if stater == 21 | stater == 22 | stater == 23
replace region = 2 if stater == 31 | stater == 32 | stater == 33 | ///
	stater == 34 | stater == 35
replace region = 2 if stater == 41 | stater == 42 | stater == 43 | ///
	stater == 44 | stater == 45 | stater == 46 | stater == 47
replace region = 3 if stater == 51 | stater == 52 | stater == 53 | ///
	stater == 54 | stater == 55 | stater == 56 | stater == 57 | ///
	stater == 58 | stater == 59
replace region = 3 if stater == 61 | stater == 62 | stater == 63 | ///
	stater == 64
replace region = 3 if stater == 71 | stater == 72 | stater == 73 | ///
	stater == 74
replace region = 4 if stater == 81 | stater == 82 | stater == 83 | ///
	stater == 84 | stater == 85 | stater == 86 | stater == 87 | ///
	stater == 88
replace region = 4 if stater == 91 | stater == 92 | stater == 93 | ///
	stater == 94 | stater == 95

* Create age group
gen age_grp = .
replace age_grp = 1 if age >= 25 & age <= 29
replace age_grp = 2 if age >= 30 & age <= 34
replace age_grp = 3 if age >= 35 & age <= 39
replace age_grp = 4 if age >= 40 & age <= 44
replace age_grp = 5 if age >= 45 & age <= 49
replace age_grp = 6 if age >= 50 & age <= 54
replace age_grp = 7 if age >= 55 & age <= 59
replace age_grp = 8 if age >= 60 & age <= 64
replace age_grp = 9 if age >= 65 & age <= 69
replace age_grp = 10 if age >= 70 & age <= 74
replace age_grp = 11 if age >= 75 & age <= 79
replace age_grp = 12 if age >= 80 & age <= 84

* Create education group
gen educ = .
replace educ = 0 if educ_orig == 1
replace educ = 1 if educ_orig == 2
replace educ = 5 if educ_orig == 3
replace educ = 7 if educ_orig == 4
replace educ = 9 if educ_orig == 5
replace educ = 10 if educ_orig == 6
replace educ = 11 if educ_orig == 7
replace educ = 12 if educ_orig == 8
replace educ = 14 if educ_orig == 9 | educ_orig == 10
replace educ = 16 if educ_orig == 11 | educ_orig == 12
replace educ = 18 if educ_orig == 13 | educ_orig == 14

* Create education - 6 groups
gen educ_grp6 = .
replace educ_grp6 = 1 if educ == 0 | educ == 1 | ///
	educ == 5 | educ == 7
replace educ_grp6 = 2 if educ == 9 | educ == 10 | ///
	educ == 11
replace educ_grp6 = 3 if educ == 12
replace educ_grp6 = 4 if educ == 14
replace educ_grp6 = 5 if educ == 16
replace educ_grp6 = 6 if educ == 18

* Create education - 3 groups
gen educ_grp3 = .
replace educ_grp3 = 1 if educ == 0 | educ == 1 | ///
	educ == 5 | educ == 7 | educ == 9 | ///
	educ == 10 | educ == 11
replace educ_grp3 = 2 if educ == 12
replace educ_grp3 = 3 if educ == 14 | educ == 16 | ///
	educ == 18

* Create education dummies
gen educ_dum1 = ( educ <= 7 )
gen educ_dum2 = ( educ >= 9 & educ <= 11 )
gen educ_dum3 = ( educ == 12 )
gen educ_dum4 = ( educ == 14 )
gen educ_dum5 = ( educ == 16 )
gen educ_dum6 = ( educ == 18 )

* Restrict sample (wait a year)
keep if follow > 365

* Create mortality indicator
gen mort_ind = 0
replace mort_ind = 1 if follow > 365 & follow <= 2191

* Create mortality sample label
gen mort_window = 1983

* Label variables
do code/label_data.do

* Save
compress
save temp/nlms_cleaned.dta, replace
