clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\NLMS"

* Load cleaned dataset
use temp/nlms_cleaned.dta

* Restrict sample (based on age, race, ethnicity, missing educ, missing weight)
drop if age < 25 | age > 84
keep if race == 1 | race == 2
keep if hisp == 3
drop if educ_grp6 == .
drop if wt == .
drop inddea

sort sex age race region
merge m:1 sex age race region using temp/clean_weights.dta, nogen keep(match)

* Create sex/age/race/region standardized weights
bysort sex educ_grp6: egen se_tot = total(wt)
bysort sex age_grp race region educ_grp6: egen sarge_tot = total(wt)
gen seawgtshar = sarge_tot / se_tot
gen agestdwgt = wt * agewgt / seawgtshar
drop se_tot sarge_tot seawgtshar agewgt

* Create wridits for graphs
* [Requires wridit is installed]
* ssc install wridit
wridit educ_grp6 [pw = agestdwgt], by(sex) gen(edrank_current) percent

* Order and save data
order record mort_window sex race hisp age hhid region stater educ ///
	educ_orig educ_grp6 edrank_current mort_ind follow agestdwgt wt
sort record
compress
save output/nlms1980s.dta, replace
