**** run_directory.do ****
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NLMS"

do code/clean_raw_data.do
do code/create_nlms_sample.do
