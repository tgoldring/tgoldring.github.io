label var record "Record Number"
label var age "Age at Time of Interview"
label var age_grp "Age - 5-year Groups"
label var race "Race"
label var sex "Sex"
label var hisp "Hispanic Origin"
label var region "Region"
label var educ "Highest Grade Completed"
label var educ_orig "Highest Grade Completed - Original Variable"
label var educ_grp6 "Education Completed - 6 Groups"
label var educ_grp3 "Education Completed - 3 Groups"
label var educ_dum1 "Education Dummy - Grade 8 and Below"
label var educ_dum2 "Education Dummy - Grade 9 - Grade 11"
label var educ_dum3 "Education Dummy - Grade 12"
label var educ_dum4 "Education Dummy - Some College"
label var educ_dum5 "Education Dummy - 4-Year College"
label var educ_dum6 "Education Dummy - More than 4-Year College"
label var wt "Adjusted Weight"
label var hhid "Household ID No."
label var inddea "Death Indicator"
label var follow "Length of Follow-up"
label var stater "State Recode"
label var mort_ind "Mortality Indicator"
label var mort_window "Sample No."

#delimit ;

label define race_l
	1 "White"
	2 "Black"
	3 "American Indian or Eskimo"
	4 "Asian or Pacific Islander"
	5 "Other nonwhite"
	;
label define sex_l
	1 "Male"
	2 "Female"
	;
label define hisp_l
	1 "Mexicans"
	2 "Other Hispanics"
	3 "Non-Hispanics"
	;
label define age_grp_l
	1 "25-29 years old"
	2 "30-34 years old"
	3 "35-39 years old"
	4 "40-44 years old"
	5 "45-49 years old"
	6 "50-54 years old"
	7 "55-59 years old"
	8 "60-64 years old"
	9 "65-69 years old"
	10 "70-74 years old"
	11 "75-79 years old"
	12 "80-84 years old"
	;
label define educ_orig_l
	1 "None, less than E1"
	2 "Completed E1, E2, E3, E4"
	3 "Completed E5, E6"
	4 "Completed E7, E8"
	5 "Completed H1"
	6 "Completed H2"
	7 "Completed H3"
	8 "Completed H4"
	9 "Completed C1"
	10 "Completed C2"
	11 "Completed C3"
	12 "Completed C4"
	13 "Compelted C5"
	14 "Completed C6"
	;
label define educ_l
	0 "Never attended; kindergarten only"
	1 "Grade 1 - Grade 4"
	5 "Grade 5 - Grade 6"
	7 "Grade 7 - Grade 8"
	9 "Grade 9"
	10 "Grade 10"
	11 "Grade 11"
	12 "Grade 12"
	14 "Some college"
	16 "College 4 years"
	18 "College >4 years"
	;
label define educ_grp6_l
	1 "Grade 8 and below"
	2 "Grades 9 to 11"
	3 "Grade 12"
	4 "Some college"
	5 "College 4 years"
	6 "College >4 years"
	;
label define educ_grp3_l
	1 "Less than grade 12"
	2 "Grade 12"
	3 "Some or more college"
	;
label define educ_dum_l
	0 "Not in dummy"
	1 "In dummy"
	;
label define inddea_l
	0 "Alice"
	1 "Dead"
	;
label define stater_l
	11 "Maine"
	12 "New Hampshire"
	13 "Vermont"
	14 "Massachusetts"
	15 "Rhode Island"
	16 "Connecticut"
	21 "New York"
	22 "New Jersey"
	23 "Pennsylvania"
	31 "Ohio"
	32 "Indiana"
	33 "Illinois"
	34 "Michigan"
	35 "Wisconsin"
	41 "Minnesota"
	42 "Iowa"
	43 "Missouri"
	44 "North Dakota"
	45 "South Dakota"
	46 "Nebraska"
	47 "Kansas"
	51 "Delaware"
	52 "Maryland"
	53 "District of Columbia"
	54 "Virgina"
	55 "West Virginia"
	56 "North Carolina"
	57 "South Carolina"
	58 "Georgia"
	59 "Florida"
	61 "Kentucky"
	62 "Tennessee"
	63 "Alabama"
	64 "Mississippi"
	71 "Arkansas"
	72 "Louisiana"
	73 "Oklahoma"
	74 "Texas"
	81 "Montana"
	82 "Idaho"
	83 "Wyoming"
	84 "Colorado"
	85 "New Mexico"
	86 "Arizona"
	87 "Utah"
	88 "Nevada"
	91 "Washington"
	92 "Oregon"
	93 "California"
	94 "Alaska"
	95 "Hawaii"
	;
label define region_l
	1 "Northeast"
	2 "Midwest"
	3 "South"
	4 "West"
	;
label define mort_ind_l
	0 "Assumed Alive"
	1 "Assumed Deceased"
	;

#delimit cr

label values race race_l
label values sex sex_l
label values hisp hisp_l
label values age_grp age_grp_l
label values educ educ_l
label values educ_orig educ_orig_l
label values educ_grp6 educ_grp6_l
label values educ_grp3 educ_grp3_l
forvalues i = 1(1)6 {
	label values educ_dum`i' educ_dum_l
}
label values inddea inddea_l
label values stater stater_l
label values region region_l
label values mort_ind mort_ind_l
