README FOR NLMS CODE

1. "run_directory.do" in the 'code' folder prepares the final NLMS datasets used in the paper, from initial downloaded raw data to final datasets.

2. Use "run_directory.do" to understand the order in which all other do files run in Stata.

3. Raw (unedited, restricted access) NMLS files are located in the 'input' folder. Extract the restricted access files into the 'input' folder.

4. The final NLMS dataset used in the paper is located in the 'output' folder.

5. The 'temp' folder stores two datasets used to create the final NHIS datasets in the 'output' folder. It will be populated by running "run_directory.do".

6. Additional detail on specific commands may be found within each do file.
