README FOR ALL DATA CODE

1. "run_directory.do" in the 'Data' folder creates the master dataset from scratch.

2. See the subfolders for further information.
