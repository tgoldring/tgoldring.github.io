README FOR NHIS CODE

1. "run_directory.do" in the 'code' folder prepares the final NHIS datasets used in the paper, from initial downloaded raw data to final datasets.

2. Use "run_directory.do" to understand the order in which all other do files run in Stata.

3. Raw (unedited) NHIS files from the CDC website are located in subfolders (one subfolder per year) in the 'input' folder. Download and extract the files year-by-year into the appropriate folder.

4. Raw (unedited) mortality files from the CDC are located in the 'mortality' sufolder in the 'input' folder. The naming convention is 'mortYYYY.DAT', e.g., 'mort1986.DAT'

5. The final NHIS datasets used in the paper are located in the 'output' folder.

6. The 'temp' folder stores numerous datasets used to create the final NHIS datasets in the 'output' folder. It will be populated with datasets by running "run_directory.do".

7. Additional detail on specific commands may be found within each do file.
