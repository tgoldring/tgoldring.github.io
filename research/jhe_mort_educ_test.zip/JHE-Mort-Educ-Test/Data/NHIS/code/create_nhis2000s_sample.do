clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NHIS"

use temp/clean_nhis/clean_nhis1986.dta, clear

forvalues i = 1987(1)2000 {
	append using temp/clean_nhis/clean_nhis`i'.dta
}

* Restrict sample (wait at least a year, non-Hisp. whites and blacks only)
keep if dodyear >= 2002
gen mort_window = 2002
keep if eligstat == 1
drop if race == 3
keep if hisp == 0

* Combine birth month and year variables
gen brth_mth = .
forvalues i = 1(1)12 {
	replace brth_mth = `i' if brth_mth86 == `i' | brth_mth93 == `i' | ///
	brth_mth97 == `i'
}

gen brth_yr = .
forvalues i = 1883(1)1986 {
	replace brth_yr = `i' if brth_yr86 == `i' | brth_yr96 == `i' | ///
	brth_yr97 == `i'
}

* Create age variables
gen age = floor((ym(2002, 1) - ym(brth_yr, brth_mth))/ 12)
drop if age > 84

sort age
merge m:1 sex age race region using temp/weights/clean_weights.dta, ///
	nogen keep(match)

gen age_grp = .
replace age_grp = 1 if age >= 25 & age <= 29
replace age_grp = 2 if age >= 30 & age <= 34
replace age_grp = 3 if age >= 35 & age <= 39
replace age_grp = 4 if age >= 40 & age <= 44
replace age_grp = 5 if age >= 45 & age <= 49
replace age_grp = 6 if age >= 50 & age <= 54
replace age_grp = 7 if age >= 55 & age <= 59
replace age_grp = 8 if age >= 60 & age <= 64
replace age_grp = 9 if age >= 65 & age <= 69
replace age_grp = 10 if age >= 70 & age <= 74
replace age_grp = 11 if age >= 75 & age <= 79
replace age_grp = 12 if age >= 80 & age <= 84

gen brth_grp = .
replace brth_grp = 1 if	brth_yr <= 1910
replace brth_grp = 2 if brth_yr >= 1911 & brth_yr <= 1915
replace brth_grp = 3 if brth_yr >= 1916 & brth_yr <= 1920
replace brth_grp = 4 if brth_yr >= 1921 & brth_yr <= 1925
replace brth_grp = 5 if brth_yr >= 1926 & brth_yr <= 1930
replace brth_grp = 6 if brth_yr >= 1931 & brth_yr <= 1935
replace brth_grp = 7 if brth_yr >= 1936 & brth_yr <= 1940
replace brth_grp = 8 if brth_yr >= 1941 & brth_yr <= 1945
replace brth_grp = 9 if brth_yr >= 1946 & brth_yr <= 1950
replace brth_grp = 10 if brth_yr >= 1951 & brth_yr <= 1955
replace brth_grp = 11 if brth_yr >= 1956 & brth_yr <= 1960
replace brth_grp = 12 if brth_yr >= 1961 & brth_yr <= 1965
replace brth_grp = 13 if brth_yr >= 1966 & brth_yr <= 1970
replace brth_grp = 14 if brth_yr >= 1971

* Create mortality indicator (Jan. 2002 - Dec. 2006)
gen mort_ind = 0
replace mort_ind = 1 if dodyear >= 2002 & dodyear <= 2006

* Create education variables
gen educ = .
forvalues i = 0(1)11 {
	replace educ = `i' if educ86 == `i' | educ97 == `i'
}
replace educ = 12 if educ86 == 12 | educ97 == 12 | educ97 == 13 | educ97 == 14
replace educ = 14 if educ86 == 13 | educ86 == 14 | educ86 == 15 | ///
	educ97 == 15 | educ97 == 16 | educ97 == 17
replace educ = 16 if educ86 == 16 | educ97 == 18
replace educ = 18 if educ86 == 17 | educ86 == 18 | educ97 == 19 | ///
	educ97 == 20 | educ97 == 21

gen educ_dum1 = ( educ <= 8 )
gen educ_dum2 = ( educ == 9 | educ == 10 | educ == 11 )
gen educ_dum3 = ( educ == 12 )
gen educ_dum4 = ( educ == 14 )
gen educ_dum5 = ( educ == 16 )
gen educ_dum6 = ( educ == 18 )

gen educ_grp6 = .
forvalues i = 0(1)8 {
	replace educ_grp6 = 1 if educ == `i'
}
replace educ_grp6 = 2 if (educ == 9 | educ == 10 | educ == 11)
replace educ_grp6 = 3 if educ == 12
replace educ_grp6 = 4 if educ == 14
replace educ_grp6 = 5 if educ == 16
replace educ_grp6 = 6 if educ == 18
drop if educ_grp6 == .

gen educ_grp3 = .
forvalues i = 0(1)11 {
	replace educ_grp3 = 1 if educ == `i'
}
replace educ_grp3 = 2 if educ == 12
replace educ_grp3 = 3 if educ == 14 | educ == 16 | educ == 18

* Calculate age-race-region standardized weights
bysort sex educ_grp6: egen se_tot = total(wt)
bysort sex age_grp race region educ_grp6: egen sarge_tot = total(wt)
gen seawgtshar = sarge_tot / se_tot
gen agestdwgt = wt * agewgt / seawgtshar
drop se_tot sarge_tot seawgtshar agewgt

* Calculate current and cohort rank and indicators
* [Requires wridit is installed]
* ssc install wridit
wridit educ_grp6 [pw = agestdwgt], by(sex) gen(edrank_current) percent
sort brth_grp sex educ
merge m:1 brth_grp sex educ using temp/cohort_ranks.dta, keep(match) nogen

label var mort_window "Sample #"
label var brth_mth "Month of Birth"
label var brth_mth86 "Month of Birth (Starting in 1986)"
label var brth_mth93 "Month of Birth (Starting in 1993)"
label var brth_mth97 "Month of Birth (Starting in 1997)"
label var brth_yr "Year of Birth"
label var brth_yr86 "Year of Birth (Starting in 1986)"
label var brth_yr96 "Year of Birth (Starting in 1996)"
label var brth_yr97 "Year of Birth (Starting in 1997)"
label var age "Age at Start of Mortality Window"
label var age_grp "Age - 5-Year Groups"
label var brth_grp "Birth Year - Grouped"
label var educ "Education Completed"
label var educ_grp6 "Education Completed - 6 Groups"
label var educ_grp3 "Education Completed - 3 Groups"
label var agestdwgt "Age-Standardized Weight"
label var edrank_current "Education Rank - Current"
label var educ_dum1 "Education Dummy - Grade 8 and Below"
label var educ_dum2 "Education Dummy - Grade 9 - Grade 11"
label var educ_dum3 "Education Dummy - Grade 12"
label var educ_dum4 "Education Dummy - Some College"
label var educ_dum5 "Education Dummy - 4-Year College"
label var educ_dum6 "Education Dummy - More than 4-Year College"
label var mort_ind "Mortality Indicator 1992-1996"

#delimit ;

label define brth_mth_l
	1 "January"
	2 "February"
	3 "March"
	4 "April"
	5 "May"
	6 "June"
	7 "July"
	8 "August"
	9 "September"
	10 "October"
	11 "November"
	12 "December"
	;
label define age_grp_l
	1 "25-29 years old"
	2 "30-34 years old"
	3 "35-39 years old"
	4 "40-44 years old"
	5 "45-49 years old"
	6 "50-54 years old"
	7 "55-59 years old"
	8 "60-64 years old"
	9 "65-69 years old"
	10 "70-74 years old"
	11 "75-79 years old"
	12 "80-84 years old"
	;
label define brth_grp_lbl
	1 "Before 1910"
	2 "Between 1911 and 1915"
	3 "Between 1916 and 1920"
	4 "Between 1921 and 1925"
	5 "Between 1926 and 1930"
	6 "Between 1931 and 1935"
	7 "Between 1936 and 1940"
	8 "Between 1941 and 1945"
	9 "Between 1946 and 1950"
	10 "Between 1951 and 1955"
	11 "Between 1956 and 1960"
	12 "Between 1961 and 1965"
	13 "Between 1966 and 1970"
	14 "After 1971"
	;
label define mort_ind_l
	0 "Assumed Alive"
	1 "Assumed Deceased"
	;
label define educ_lbl
	0 "Never attended; kindergarten only"
	1 "Grade 1"
	2 "Grade 2"
	3 "Grade 3"
	4 "Grade 4"
	5 "Grade 5"
	6 "Grade 6"
	7 "Grade 7"
	8 "Grade 8"
	9 "Grade 9"
	10 "Grade 10"
	11 "Grade 11"
	12 "Grade 12"
	14 "Some college"
	16 "College 4 years"
	18 "College >4 years"
	;
label define educ_grp6_l
	1 "Grade 8 and below"
	2 "Grades 9 to 11"
	3 "Grade 12"
	4 "Some college"
	5 "College 4 years"
	6 "College >4 years"
	;
label define educ_grp3_l
	1 "Less than high school"
	2 "High school"
	3 "Some or more college"
	;
label define educ_dum_l
	0 "Not in dummy"
	1 "In dummy"
	;

#delimit cr

label values brth_mth brth_mth_l
label values age_grp age_grp_l
label values brth_grp brth_grp_l
label values mort_ind mort_ind_l
label values educ educ_lbl
label values educ_grp6 educ_grp6_l
label values educ_grp3 educ_grp3_l
forvalues i = 1(1)6 {
	label values educ_dum`i' educ_dum_l
}

order record mort_window svy_yr sex race hisp age age_grp age86 brth_grp ///
	brth_mth brth_mth* brth_yr brth_yr* region educ educ_grp6 educ_grp3 ///
	edrank_current edrank_cohort educ_dum* educ86 mort_ind mortstat ///
	eligstat dodqtr dodyear agestdwgt wt

sort svy_yr record
compress

save output/nhis2000s.dta, replace

* Check weights are correct
log using temp/weights/nhis2000s_check_weights.log, replace
set linesize 240
tablecol age_grp educ_grp6 sex [pw = agestdwgt], colpct format(%10.0f)
log close
