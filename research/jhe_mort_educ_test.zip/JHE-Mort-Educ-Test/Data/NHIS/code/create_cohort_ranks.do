clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NHIS"

* Load 1986-2000 datasets
use temp/clean_nhis/clean_nhis1986.dta, clear

forvalues i = 1987(1)2000 {
	append using temp/clean_nhis/clean_nhis`i'.dta
}

order record svy_yr sex age* brth_mth* brth_yr* race hisp educ* wt

* Mortality window
keep if eligstat == 1

* Non Hisp. white or black only
drop if race == 3
keep if hisp == 0

* Merge year of birth variables
gen brth_yr = .
forvalues i = 1883(1)1986 {
	replace brth_yr = `i' if brth_yr86 == `i' | brth_yr96 == `i' | ///
	brth_yr97 == `i'
}
label var brth_yr "Birth Year"
order brth_yr, before(brth_yr86)

* Create grouped birth year variable
gen brth_grp = .
replace brth_grp = 1 if brth_yr <= 1910
replace brth_grp = 2 if brth_yr >= 1911 & brth_yr <= 1915
replace brth_grp = 3 if brth_yr >= 1916 & brth_yr <= 1920
replace brth_grp = 4 if brth_yr >= 1921 & brth_yr <= 1925
replace brth_grp = 5 if brth_yr >= 1926 & brth_yr <= 1930
replace brth_grp = 6 if brth_yr >= 1931 & brth_yr <= 1935
replace brth_grp = 7 if brth_yr >= 1936 & brth_yr <= 1940
replace brth_grp = 8 if brth_yr >= 1941 & brth_yr <= 1945
replace brth_grp = 9 if brth_yr >= 1946 & brth_yr <= 1950
replace brth_grp = 10 if brth_yr >= 1951 & brth_yr <= 1955
replace brth_grp = 11 if brth_yr >= 1956 & brth_yr <= 1960
replace brth_grp = 12 if brth_yr >= 1961 & brth_yr <= 1965
replace brth_grp = 13 if brth_yr >= 1966 & brth_yr <= 1970
replace brth_grp = 14 if brth_yr >= 1971

label var brth_grp "Birth Year - Grouped"
#delimit ;
label define brth_grpl
	1 "Before 1910"
	2 "Between 1911 and 1915"
	3 "Between 1916 and 1920"
	4 "Between 1921 and 1925"
	5 "Between 1926 and 1930"
	6 "Between 1931 and 1935"
	7 "Between 1936 and 1940"
	8 "Between 1941 and 1945"
	9 "Between 1946 and 1950"
	10 "Between 1951 and 1955"
	11 "Between 1956 and 1960"
	12 "Between 1961 and 1965"
	13 "Between 1966 and 1970"
	14 "After 1971"
	;
#delimit cr
label values brth_grp brth_grpl
order brth_grp, after(brth_yr)

* Create education variables
gen educ = .
forvalues i = 0(1)11 {
	replace educ = `i' if educ86 == `i' | educ97 == `i'
}
replace educ = 12 if educ86 == 12 | educ97 == 12 | educ97 == 13 | educ97 == 14
replace educ = 14 if educ86 == 13 | educ86 == 14 | educ86 == 15 | ///
	educ97 == 15 | educ97 == 16 | educ97 == 17
replace educ = 16 if educ86 == 16 | educ97 == 18
replace educ = 18 if educ86 == 17 | educ86 == 18 | educ97 == 19 | ///
	educ97 == 20 | educ97 == 21

label var educ "Education Completed"
#delimit ;
label define educ_l
	0 "Never attended; kindergarten only"
	1 "Grade 1"
	2 "Grade 2"
	3 "Grade 3"
	4 "Grade 4"
	5 "Grade 5"
	6 "Grade 6"
	7 "Grade 7"
	8 "Grade 8"
	9 "Grade 9"
	10 "Grade 10"
	11 "Grade 11"
	12 "Grade 12"
	14 "Some college"
	16 "College 4 years"
	18 "College >4 years"
	;
#delimit cr
label values educ educ_l
order educ, before(educ86)
drop if educ == .

gen educ_grp6 = .
forvalues i = 0(1)8 {
	replace educ_grp6 = 1 if educ == `i'
}
replace educ_grp6 = 2 if educ == 9 | educ == 10 | educ == 11
replace educ_grp6 = 3 if educ == 12
replace educ_grp6 = 4 if educ == 14
replace educ_grp6 = 5 if educ == 16
replace educ_grp6 = 6 if educ == 18

label var educ_grp6 "Education Completed - Grouped"
#delimit ;
label define educ_grp6_l
	1 "Grade 8 and below"
	2 "Grades 9 to 11"
	3 "Grade 12"
	4 "Some college"
	5 "College 4 years"
	6 "College >4 years"
	;
#delimit cr
label values educ_grp6 educ_grp6_l
order educ_grp6, after(educ)
drop if educ_grp6 == .

* Create cohort education rank
* [Require wridit command is installed]
* ssc install wridit
sort brth_grp sex educ
wridit educ [pw=wt], gen(edrank_cohort) by(sex brth_grp) percent
label var edrank_cohort "Education Rank - Cohort"

* Save
keep sex brth_grp educ edrank_cohort
duplicates drop
compress

save temp/cohort_ranks.dta, replace
