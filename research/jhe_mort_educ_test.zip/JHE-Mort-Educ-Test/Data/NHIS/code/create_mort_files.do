clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NHIS"

#delimit ;

forvalues i = 1986(1)2000 {;

* Input data;
infix 
str record 1-14 
str publicid2 15-28
eligstat 29
mortstat 30
mortsrce_ndi 31
mortsrce_ssa 32
mortsrce_cms 33
dodqtr 34 
dodyear 35-38
causeavl 39 
str ucod_113 40-42 
diabetes 43 
hyperten 44 
hipfract 45 
wgt_new 46-53
sa_wgt_new 54-61 
using input/mortality/mort`i'.dat;

#delimit cr

label variable record "public-use id"
label variable publicid2 "alternate nhis public-use id for 1997-2003 NHIS years"
label variable eligstat "Mortality Eligibility Status"
label variable mortstat "Mortality Status"
label variable mortsrce_ndi "mortality source: NDI match"
label variable mortsrce_ssa "mortality source: SSA information"
label variable mortsrce_cms "mortality source: CMS information"
label variable dodqtr "Quarter of Death"
label variable dodyear "Year of Death"
label variable causeavl "cause of death data available"
label variable ucod_113 "underlying cause of death 113 groups all years (icd-10)"
label variable diabetes "diabetes flag from multiple cause of death (mcod)"
label variable hyperten "hypertension flag from multiple cause of death (mcod)"
label variable hipfract "hip fracture flag from multiple cause of death (mcod)"
label variable wgt_new "weight adjusted for ineligible respondents-person level sample weight"
label variable sa_wgt_new "weight adjusted for ineligible respondents-sample adult sample weight"

#delimit ;

label define eligfmt
	1 "Eligible"
	2 "Under age 18, not available for public release "
	3 "Ineligible"
	;
label define mortfmt
	0 "Assumed alive"
	1 "Assumed Deceased"
	;
label define msrcendifmt
	0 "No"
	1 "Yes"	
	;
label define msrcessafmt
	0 "No"
	1 "Yes"	
	;
label define msrcecmsfmt
	0 "No"
	1 "Yes"	
	9 "Not applicable"
	;
label define qtrfmt
	1 "January-March"
	2 "April-June"	
	3 "July-September"
	4 "October-December"
	;
label define causefmt
	0 "No"
	1 "Yes"	
	;
label define flagfmt
	0 "No"
	1 "Yes- listed as a multiple cause of death"	
	;

#delimit cr

label values eligstat eligfmt
label values mortstat mortfmt
label values mortsrce_ndi msrcendifmt
label values mortsrce_ssa msrcessafmt
label values mortsrce_cms msrcecmsfmt
label values dodqtr qtrfmt
label values causeavl causefmt
label values diabetes flagfmt
label values hyperten flagfmt
label values hipfract flagfmt

sort record
save temp/clean_mortality/clean_mort`i'.dta, replace
clear all

}
