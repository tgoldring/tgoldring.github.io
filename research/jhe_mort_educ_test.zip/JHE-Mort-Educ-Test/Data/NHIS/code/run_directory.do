**** run_directory.do ****
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NHIS"

do code/create_mort_files.do
do code/create_weights.do
do code/create_cohort_ranks.do

foreach i in 1986(1)2001 {
	do code/clean_nhis/clean_nhis`i'.do
}

do code/create_nhis1990s_sample.do
do code/create_nhis2000s_sample.do
