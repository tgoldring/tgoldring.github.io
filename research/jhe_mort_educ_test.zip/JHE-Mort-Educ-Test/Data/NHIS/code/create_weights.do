clear all
cd "C:/Users/Thomas/Box Sync/JHE-Mort-Educ-Test/Data/NHIS"

* Load 1999-2001 datasets
use temp/clean_nhis/clean_nhis1999.dta, clear

forvalues i = 2000(1)2001 {
	append using temp/clean_nhis/clean_nhis`i'.dta
}

* Mortality window
keep if eligstat == 1

* Non-Hisp. white or black only
drop if race == 3
keep if hisp == 0

* Min. and max. age cutoff
drop if age97 < 25 | age97 > 84

* Create age groups
gen age_grp = .
replace age_grp = 1 if age97 >= 25 & age97 <= 29
replace age_grp = 2 if age97 >= 30 & age97 <= 34
replace age_grp = 3 if age97 >= 35 & age97 <= 39
replace age_grp = 4 if age97 >= 40 & age97 <= 44
replace age_grp = 5 if age97 >= 45 & age97 <= 49
replace age_grp = 6 if age97 >= 50 & age97 <= 54
replace age_grp = 7 if age97 >= 55 & age97 <= 59
replace age_grp = 8 if age97 >= 60 & age97 <= 64
replace age_grp = 9 if age97 >= 65 & age97 <= 69
replace age_grp = 10 if age97 >= 70 & age97 <= 74
replace age_grp = 11 if age97 >= 75 & age97 <= 79
replace age_grp = 12 if age97 >= 80 & age97 <= 84

* Prepare weights
bysort sex: egen s_tot = total(wt)
bysort sex age_grp race region: egen sarg_tot = total(wt)
gen agewgt = sarg_tot / s_tot

rename age97 age
keep sex age race region agewgt

duplicates drop

save temp/weights/clean_weights.dta, replace
save ../NLMS/temp/clean_weights.dta, replace
