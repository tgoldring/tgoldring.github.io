clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\NHIS"

use year quarter weekcen psunumr segnum hhnum pnum sex age birthmo birthyr ///
	racer1 hispanic educ region wtfa using temp/raw_nhis/nhis1994.dta, clear

* Glossary:
* racer1: race (recode1 - white/black/other)
* hispanic: hispanic origin
* wtfa: weight

* Create ID variable
gen str2 week = string(weekcen, "%02.0f")
egen record = concat(year quarter psunumr week segnum hhnum pnum)

* Create Hispanic indicator
gen hisp = 0
replace hisp = 1 if hispanic >= 0 & hispanic <= 8
replace hisp = 9 if hispanic == 9

* Swap year
replace year = 1994

* Rename variables
ren year svy_yr
ren age age86
ren birthmo brth_mth93
ren birthyr brth_yr86
ren racer1 race
ren educ educ86
ren wtfa wt

* Destring month and year of birth
destring brth_mth93 brth_yr86, replace

* [requires keepvar is installed]
* ssc install keepvar
keepvar record svy_yr sex age86 brth_mth93 brth_yr86 race hisp educ86 ///
	region wt, asis

label var record "ID"
label var svy_yr "Survey Year"
label var sex "Sex"
label var age86 "Age"
label var brth_mth93 "Month of Birth"
label var brth_yr86 "Year of Birth"
label var race "Race"
label var hisp "Hispanic Indicator"
label var educ86 "Education Completed"
label var region "Region"
label var wt "Weight - Original"

#delimit ;

label define sex_l
	1 "Male"
	2 "Female"
	;
label define brth_mth93_l
	1 "January"
	2 "February"
	3 "March"
	4 "April"
	5 "May"
	6 "June"
	7 "July"
	8 "August"
	9 "September"
	10 "October"
	11 "November"
	12 "December"
	99 "Refused"
	;
label define race_l
	1 "White"
	2 "Black"
	3 "Other"
	;
label define hisp_l
	0 "Non-Hispanic"
	1 "Hispanic"
	9 "Unknown"
	;
label define educ86_l
	0 "Never attended; kindergarten only"
	1 "Grade 1"
	2 "Grade 2"
	3 "Grade 3"
	4 "Grade 4"
	5 "Grade 5"
	6 "Grade 6"
	7 "Grade 7"
	8 "Grade 8"
	9 "Grade 9"
	10 "Grade 10"
	11 "Grade 11"
	12 "Grade 12"
	13 "College 1 year"
	14 "College 2 years"
	15 "College 3 years"
	16 "College 4 years"
	17 "College 5 years"
	18 "College 6 years or more"
	19 "Unknown"
	;
label define region_l
	1 "Northeast"
	2 "Midwest"
	3 "South"
	4 "West"
	;

#delimit cr

label values sex sex_l
label values brth_mth93 brth_mth93_l
label values race race_l
label values hisp hisp_l
label values educ86 educ86_l
label values region region_l

* Sort and merge mortality data
sort record
merge 1:1 record using temp/clean_mortality/clean_mort1994.dta, ///
	keepusing(eligstat mortstat dodqtr dodyear) nogen

* Remove under 25 years old
drop if age86 < 25

* Save
compress
save temp/clean_nhis/clean_nhis1994.dta, replace
