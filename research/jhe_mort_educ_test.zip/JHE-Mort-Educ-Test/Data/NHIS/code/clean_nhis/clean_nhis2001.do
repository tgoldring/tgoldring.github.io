clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\NHIS"

use srvy_yr hhx fmx px sex age_p dob_m dob_y_p racrec_i origin_i hiscod_i ///
	educ region wtfa using temp/raw_nhis/nhis2001.dta, clear

* Glossary:
* racrec_i: race (white/black/other)
* origin_i: hispanic origin
* wtfa: weight

* Create ID variable
egen record = concat(srvy_yr hhx fmx px)

* Create Hispanic indicator
gen hisp = 0
replace hisp = 1 if origin == 1

* Rename variables
ren srvy_yr svy_yr
ren age_p age97
ren dob_m brth_mth97
ren dob_y_p brth_yr97
ren racrec_i race
ren educ educ97

* Destring month and year of birth
destring brth_mth97 brth_yr97, replace

* [requires keepvar is installed]
* ssc install keepvar
keepvar record svy_yr sex age97 brth_mth97 brth_yr97 race hisp educ97 ///
	region wt, asis

label var record "ID"
label var svy_yr "Survey Year"
label var sex "Sex"
label var age97 "Age"
label var brth_mth97 "Month of Birth"
label var brth_yr97 "Year of Birth"
label var race "Race"
label var hisp "Hispanic Indicator"
label var educ97 "Education Completed"
label var region "Region"
label var wt "Weight - Original"

#delimit ;

label define sex_l
	1 "Male"
	2 "Female"
	;
label define brth_mth97_l
	1 "January"
	2 "February"
	3 "March"
	4 "April"
	5 "May"
	6 "June"
	7 "July"
	8 "August"
	9 "September"
	10 "October"
	11 "November"
	12 "December"
	97 "Refused"
	98 "Not ascertained"
	99 "Don't know"
	;
label define race_l
	1 "White"
	2 "Black"
	3 "Other"
	;
label define hisp_l
	0 "Non-Hispanic"
	1 "Hispanic"
	;
label define educ97_l
	0 "Never attended; kindergarten only"
	1 "Grade 1"
	2 "Grade 2"
	3 "Grade 3"
	4 "Grade 4"
	5 "Grade 5"
	6 "Grade 6"
	7 "Grade 7"
	8 "Grade 8"
	9 "Grade 9"
	10 "Grade 10"
	11 "Grade 11"
	12 "Grade 12, no diploma"
	13 "High school graduate"
	14 "GED or equivalent"
	15 "Some college, no degree"
	16 "AA degree: technical or vocational"
	17 "AA degree: academic program"
	18 "Bachelor's degree (BA, AB, BS, BBA)"
	19 "Master's degree (MA, MS, MEng, MEd, MBA)"
	20 "Professional degree (MD, DDS, DVM, JD)"
	21 "Doctoral degree (PhD, EdD)"
	96 "Child under 5 years old"
	97 "Refused"
	98 "Not ascertained"
	99 "Don't know"
	;
label define region_l
	1 "Northeast"
	2 "Midwest"
	3 "South"
	4 "West"
	;

#delimit cr

label values sex sex_l
label values brth_mth97 brth_mth97_l
label values race race_l
label values hisp hisp_l
label values educ97 educ97_l
label values region region_l

* Remove under 25 years old
drop if age97 < 25

* Save
sort record
compress
save temp/clean_nhis/clean_nhis2001.dta, replace
