* JHE APPENDIX TABLES

* This file produces the data in Table A1 and Table A2.

* It uses user-created command `tablecol' by Nicholas Winter.
* ssc install tablecol

clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\combine\output"

use master.dta

* TABLE A1

* Population shares
tablecol educ_grp6 sex mort_window [pw = agestdwgt], colpct nofreq

* Mortality rates
table educ_grp6 sex mort_window [aw = agestdwgt], c(mean mort_ind) format(%8.3f)

* TABLE A2

* Demeaned mortality rates
table educ_grp6 sex mort_window [aw = agestdwgt], c(mean mort_ind_demean semean mort_ind_demean)

* Use `Copy table' in Stata and paste into the Excel file ``Table A2'' to replicate Table A2.
* Precise directions are given in the Excel file.
