* JHE TABLE 2

* This file produces the data in Table 2.

clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\combine\output"

use master.dta

* Sample size by data source
tab mort_window
