* JHE TABLE 1

* This file produces the data in Table 1.

* It uses user-created command `tablecol' by Nicholas Winter.
* ssc install tablecol

clear all
cd "C:\Users\Thomas\Box Sync\JHE-Mort-Educ-Test\Data\combine\output"

use master.dta

* Population shares
tablecol educ_grp3 mort_window [pw = agestdwgt] if sex == 2 & ///
	(mort_window == 1983 | mort_window == 2002), colpct nofreq

* Mortality rates
table educ_grp3 mort_window [aw = agestdwgt] if sex == 2 & ///
	(mort_window == 1983 | mort_window == 2002), c(mean mort_ind) format(%8.3f)
